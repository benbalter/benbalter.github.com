=== Plugin Name ===
Contributors: benbalter
Donate link: http://ben.balter.com
Tags: emphasis, highlight, nyt, new york times
Requires at least: 3.0
Tested up to: 3.1
Stable tag: .1-beta

One-click implementation of the New York Times open source emphasis script.

== Description ==

One-click implementation of the [New York Times open source emphasis script](http://open.blogs.nytimes.com/2011/01/11/emphasis-update-and-source/).

Allows permalinking/highlighting of individual paragraphs/sentences.

No need to set anything up. Just install and start highlighting. See [The New York Times](http://open.blogs.nytimes.com/2011/01/11/emphasis-update-and-source/) for syntax more information on general usage.

== Installation ==

Install. That's it. No settings. No fuss.

== Changelog ==

= .1-beta =
* Initial release